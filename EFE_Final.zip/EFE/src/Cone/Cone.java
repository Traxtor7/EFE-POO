/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Cone;

/**
 *
 * @author AXDJG
 */
public class Cone {
    
    String dbURL = "jdbc:derby://localhost:1527/efe;";
    String user = "efe";
    String pass = "efe";

    public void setDbURL(String dbURL) {
        this.dbURL = dbURL;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getDbURL() {
        return dbURL;
    }

    public String getUser() {
        return user;
    }

    public String getPass() {
        return pass;
    }
    
}
