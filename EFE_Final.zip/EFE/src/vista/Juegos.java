/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import Cone.Cone;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author AXDJG
 */
public class Juegos extends javax.swing.JFrame {

    String sqlSelect = "SELECT * FROM JUEGOS";

    /**
     * Creates new form Juegos
     */
    public Juegos() {
        initComponents();
        this.setLocationRelativeTo(null);
        DefaultTableModel model = (DefaultTableModel) this.Tabla.getModel();

        //CARGAMOS LOS DATOS DE LA BASE DE DATOS AL INICIO EN LA TABLA
        Cone cone = new Cone();
        Connection conn1;
        try {
            conn1 = DriverManager.getConnection(cone.getDbURL(), cone.getUser(), cone.getPass());
            if (conn1 != null) {
                System.out.println("ok");

                //EJECUTAMOS UN SELECT PARA MOSTRAR TODOS LOS DATOS DE LA TABLA JUEGOS
                Statement stmt = conn1.createStatement();
                ResultSet rs = stmt.executeQuery(sqlSelect);

                while (rs.next()) {
                    //MOSTRAMOS LOS DATOS
                    model.addRow(new Object[]{rs.getString("IDJUEGOS"), rs.getString("NOMBREJUEGO"), rs.getString("PRECIOJUEGO"), rs.getString("DESCRIPCIONJUEGO"), rs.getString("JUGADORESJUEGO"), rs.getString("TIEMPOJUEGO"), rs.getString("EDADJUEGO"), rs.getString("IDIOMAJUEGO"), rs.getString("STOCKJUEGO"), rs.getString("IDCOLABORADORES")});

                }

            }
        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, "Problemas");
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Buscar = new javax.swing.JTextField();
        botonActualizar = new javax.swing.JButton();
        BotonBuscar = new javax.swing.JButton();
        ActualizarTabla = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        botonInsertar = new javax.swing.JButton();
        TexID = new javax.swing.JTextField();
        TexNombre = new javax.swing.JTextField();
        TexPrecio = new javax.swing.JTextField();
        TexDescripcion = new javax.swing.JTextField();
        TexTiempo = new javax.swing.JTextField();
        TexEdad = new javax.swing.JTextField();
        TexIdioma = new javax.swing.JTextField();
        TexStock = new javax.swing.JTextField();
        TexJugadores = new javax.swing.JTextField();
        EtiID = new javax.swing.JLabel();
        EtiNombre = new javax.swing.JLabel();
        EtiPrecio = new javax.swing.JLabel();
        EtiDescripcion = new javax.swing.JLabel();
        EtiJugadores = new javax.swing.JLabel();
        EtiTiempo = new javax.swing.JLabel();
        EtiEdad = new javax.swing.JLabel();
        EtiIdioma = new javax.swing.JLabel();
        EtiStock = new javax.swing.JLabel();
        EtiColaboradores = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        CBColaboradores = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Buscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        botonActualizar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        botonActualizar.setText("Actualizar Datos");
        botonActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActualizarActionPerformed(evt);
            }
        });

        BotonBuscar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BotonBuscar.setText("Buscar por Nombre");
        BotonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonBuscarActionPerformed(evt);
            }
        });

        ActualizarTabla.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        ActualizarTabla.setText("Actualizar Tabla");
        ActualizarTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ActualizarTablaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(95, Short.MAX_VALUE)
                .addComponent(ActualizarTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(BotonBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(310, 310, 310))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BotonBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ActualizarTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.PAGE_END);

        botonInsertar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        botonInsertar.setText("Insertar");
        botonInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonInsertarActionPerformed(evt);
            }
        });

        TexID.setText("N° ID");
        TexID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TexIDActionPerformed(evt);
            }
        });

        TexNombre.setText("Nombre");
        TexNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TexNombreActionPerformed(evt);
            }
        });

        TexPrecio.setText("Precio");

        TexDescripcion.setText("Descripcion");

        TexTiempo.setText("Tiempo Juego");

        TexEdad.setText("Edad Jugador");

        TexIdioma.setText("Idioma Juego");

        TexStock.setText("Cantidad de Juegos");

        TexJugadores.setText("Cantidad Jugadores");

        EtiID.setText("Id Juego");

        EtiNombre.setText("Nombre");

        EtiPrecio.setText("Precio");

        EtiDescripcion.setText("Descripcion");

        EtiJugadores.setText("Jugadores");

        EtiTiempo.setText("Tiempo");

        EtiEdad.setText("Edad");

        EtiIdioma.setText("Idioma");

        EtiStock.setText("Stock");

        EtiColaboradores.setText("Colaboradores");

        jLabel1.setText("Opcion 1 = Editor");

        jLabel2.setText("Opcion 2 = Diseñador");

        jLabel3.setText("Opcion 3 = Artista");

        CBColaboradores.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(EtiID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(EtiNombre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(EtiPrecio, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(EtiDescripcion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(EtiJugadores, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TexID)
                            .addComponent(TexNombre)
                            .addComponent(TexPrecio)
                            .addComponent(TexDescripcion)
                            .addComponent(TexJugadores, javax.swing.GroupLayout.DEFAULT_SIZE, 394, Short.MAX_VALUE))
                        .addGap(31, 31, 31)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(EtiEdad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(EtiStock, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                                .addComponent(EtiIdioma, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(EtiColaboradores, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EtiTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(botonInsertar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TexTiempo)
                    .addComponent(TexIdioma, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(TexEdad)
                    .addComponent(TexStock, javax.swing.GroupLayout.DEFAULT_SIZE, 419, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(CBColaboradores, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TexID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EtiID)
                    .addComponent(TexTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EtiTiempo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TexNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EtiNombre))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TexPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EtiPrecio))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TexDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EtiDescripcion))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TexJugadores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EtiJugadores))
                        .addGap(18, 18, 18)
                        .addComponent(botonInsertar, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TexEdad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EtiEdad))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TexIdioma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EtiIdioma))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(TexStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EtiStock))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(EtiColaboradores)
                            .addComponent(CBColaboradores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3))))))
        );

        getContentPane().add(jPanel2, java.awt.BorderLayout.PAGE_START);

        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id Juego", "Nombre", "Precio ", "Descripcion", "Jugadores", "Tiempo", "Edad", "Idioma", "Stock", "Colaborador"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1089, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 378, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel3, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ActualizarTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ActualizarTablaActionPerformed
        // TODO add your handling code here:

        String sqlSelectByUser = "SELECT * FROM JUEGOS ";

        DefaultTableModel model1 = (DefaultTableModel) this.Tabla.getModel();
        model1.setRowCount(0);
        //SELECT A LA BASE DE DATOS PARA CARGAR NUESTRA TABLA
        Cone cone = new Cone();
        Connection conn1;
        try {
            conn1 = DriverManager.getConnection(cone.getDbURL(), cone.getUser(), cone.getPass());
            if (conn1 != null) {
                System.out.println("ok");

                //EJECUTAMOS UN SELECT PARA MOSTRAR TODOS LOS DATOS DE LA TABLA JUEGOS
                Statement stmt = conn1.createStatement();
                ResultSet rs = stmt.executeQuery(sqlSelectByUser);

                while (rs.next()) {
                    //MOSTRAMOS LOS DATOS
                    model1.addRow(new Object[]{rs.getString("IDJUEGOS"), rs.getString("NOMBREJUEGO"), rs.getString("PRECIOJUEGO"), rs.getString("DESCRIPCIONJUEGO"), rs.getString("JUGADORESJUEGO"), rs.getString("TIEMPOJUEGO"), rs.getString("EDADJUEGO"), rs.getString("IDIOMAJUEGO"), rs.getString("STOCKJUEGO"), rs.getString("IDCOLABORADORES")});

                }

            }
        } catch (SQLException ex) {

        }

    }//GEN-LAST:event_ActualizarTablaActionPerformed

    private void botonActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActualizarActionPerformed
        // TODO add your handling code here:

        int row = this.Tabla.getSelectedRow();
        Cone cone = new Cone();
        try {
            // NOS CONECTAMOS A LA BASE DE DATOS
            Connection conn1 = DriverManager.getConnection(cone.getDbURL(), cone.getUser(), cone.getPass());

            // String UpDate
            String sqlUpdate = "UPDATE JUEGOS SET NOMBREJUEGO = ?, PRECIOJUEGO = ?, DESCRIPCIONJUEGO = ?, JUGADORESJUEGO = ?, TIEMPOJUEGO = ?, EDADJUEGO = ?, IDIOMAJUEGO = ?, STOCKJUEGO = ?, IDCOLABORADORES = ? WHERE IDJUEGOS = " + this.Tabla.getValueAt(row, 0).toString() + " ";
            System.out.println(" SQL CREATOR " + sqlUpdate);
            PreparedStatement preparedStmt = conn1.prepareStatement(sqlUpdate);

            preparedStmt.setString(1, this.Tabla.getValueAt(row, 1).toString());
            preparedStmt.setString(2, this.Tabla.getValueAt(row, 2).toString());
            preparedStmt.setString(3, this.Tabla.getValueAt(row, 3).toString());
            preparedStmt.setString(4, this.Tabla.getValueAt(row, 4).toString());
            preparedStmt.setString(5, this.Tabla.getValueAt(row, 5).toString());
            preparedStmt.setString(6, this.Tabla.getValueAt(row, 6).toString());
            preparedStmt.setString(7, this.Tabla.getValueAt(row, 7).toString());
            preparedStmt.setString(8, this.Tabla.getValueAt(row, 8).toString());
            preparedStmt.setString(9, this.Tabla.getValueAt(row, 9).toString());

            //Ejecutar Update
            preparedStmt.executeUpdate();

            conn1.close();
            JOptionPane.showMessageDialog(null, "Se ha actualiado el registro correctamente");
        } catch (SQLException ex) {
            System.err.println("Got an exception! ");
            JOptionPane.showMessageDialog(null, "Problemas al insertar datos " + ex.getMessage());
            System.err.println(ex.getMessage());
        }

    }//GEN-LAST:event_botonActualizarActionPerformed

    private void botonInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonInsertarActionPerformed
        // TODO add your handling code here:

        String sqlCreate = "INSERT INTO EFE.JUEGOS VALUES(" + this.TexID.getText() + ",'" + this.TexNombre.getText() + "'," + this.TexPrecio.getText() + ",'" + this.TexDescripcion.getText() + "'," + this.TexJugadores.getText() + "," + this.TexTiempo.getText() + "," + this.TexEdad.getText() + ",'" + this.TexIdioma.getText() + "'," + this.TexStock.getText() + "," + this.CBColaboradores.getSelectedItem() + ")";
        System.out.println(" SQL CREATOR " + sqlCreate);
        Cone cone = new Cone();

        try {
            Connection conn1 = DriverManager.getConnection(cone.getDbURL(), cone.getUser(), cone.getPass());
            if (conn1 != null) {
                Statement st = conn1.createStatement();
                st.executeUpdate(sqlCreate);
                conn1.close();
                JOptionPane.showMessageDialog(null, "Dato Insertado");
            }
        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(null, "Problemas al insertar datos " + ex.getMessage());
        }


    }//GEN-LAST:event_botonInsertarActionPerformed

    private void TexNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TexNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TexNombreActionPerformed

    private void BotonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonBuscarActionPerformed
        // TODO add your handling code here:

        String sqlSelectByUser = "SELECT * FROM JUEGOS WHERE NOMBREJUEGO = '" + this.Buscar.getText() + "'";

        DefaultTableModel model1 = (DefaultTableModel) this.Tabla.getModel();
        model1.setRowCount(0);
        //SELECT A LA BASE DE DATOS PARA CARGAR NUESTRA TABLA
        Cone cone = new Cone();
        Connection conn1;
        try {
            conn1 = DriverManager.getConnection(cone.getDbURL(), cone.getUser(), cone.getPass());
            if (conn1 != null) {
                System.out.println("ok");

                //Código para ejecutar sentencia SELECT
                Statement stmt = conn1.createStatement();
                ResultSet rs = stmt.executeQuery(sqlSelectByUser);

                while (rs.next()) {
                    //Display values
                    model1.addRow(new Object[]{rs.getString("IDJUEGOS"), rs.getString("NOMBREJUEGO"), rs.getString("PRECIOJUEGO"), rs.getString("DESCRIPCIONJUEGO"), rs.getString("JUGADORESJUEGO"), rs.getString("TIEMPOJUEGO"), rs.getString("EDADJUEGO"), rs.getString("IDIOMAJUEGO"), rs.getString("STOCKJUEGO"), rs.getString("IDCOLABORADORES")});

                }

            }
        } catch (SQLException ex) {

        }

    }//GEN-LAST:event_BotonBuscarActionPerformed

    private void TexIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TexIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TexIDActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Juegos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Juegos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Juegos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Juegos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Juegos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ActualizarTabla;
    private javax.swing.JButton BotonBuscar;
    private javax.swing.JTextField Buscar;
    private javax.swing.JComboBox<String> CBColaboradores;
    private javax.swing.JLabel EtiColaboradores;
    private javax.swing.JLabel EtiDescripcion;
    private javax.swing.JLabel EtiEdad;
    private javax.swing.JLabel EtiID;
    private javax.swing.JLabel EtiIdioma;
    private javax.swing.JLabel EtiJugadores;
    private javax.swing.JLabel EtiNombre;
    private javax.swing.JLabel EtiPrecio;
    private javax.swing.JLabel EtiStock;
    private javax.swing.JLabel EtiTiempo;
    private javax.swing.JTable Tabla;
    private javax.swing.JTextField TexDescripcion;
    private javax.swing.JTextField TexEdad;
    private javax.swing.JTextField TexID;
    private javax.swing.JTextField TexIdioma;
    private javax.swing.JTextField TexJugadores;
    private javax.swing.JTextField TexNombre;
    private javax.swing.JTextField TexPrecio;
    private javax.swing.JTextField TexStock;
    private javax.swing.JTextField TexTiempo;
    private javax.swing.JButton botonActualizar;
    private javax.swing.JButton botonInsertar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
